import pyautogui
import generateToken
import socket
import os
import emoji
import threading
import cv2
import numpy as np
from PIL import ImageGrab
import time

# globals
server = os.getenv('server')
port = os.getenv('port')
nickname = os.getenv('nickname')
token = generateToken.getAccessToken()
channel = os.getenv('channel')
twitchChat = {}
needInput = False


def stopThread():
    global stopped
    stopped = True


def thread_function():
    global stopped, twitchChat
    sock = socket.socket()
    sock.connect((server, int(port)))
    sock.send(f"PASS {token}\n".encode('utf-8'))
    sock.send(f"NICK {nickname}\n".encode('utf-8'))
    sock.send(f"JOIN {channel}\n".encode('utf-8'))
    while True and not stopped:
        resp = sock.recv(2048).decode('utf-8')
        if resp.startswith('PING'):
            sock.send("PONG\n".encode('utf-8'))

        elif len(resp) > 0:
            chatMsg = resp.split("l :")
            if len(chatMsg) > 1:
                clensedChatMsg = emoji.demojize(chatMsg[1].rstrip("\n\r")).lower()
                author = resp.split("!")[0][1:]
                if needInput:
                    # Check if chat message is a number between 1 and 12
                    if clensedChatMsg.isdigit() and int(clensedChatMsg) > 0 and int(clensedChatMsg) < 13:
                        twitchInput = int(clensedChatMsg)
                        if twitchInput not in twitchChat:
                            twitchChat[twitchInput] = 1
                        else:
                            twitchChat[twitchInput] += 1
                        print("Picked " + clensedChatMsg)
                    elif clensedChatMsg == "end":
                        if 14 not in twitchChat:
                            twitchChat[14] = 1
                        else:
                            twitchChat[14] += 1
                    elif clensedChatMsg == "roll":
                        if 13 not in twitchChat:
                            twitchChat[13] = 1
                        else:
                            twitchChat[13] += 1
                    elif clensedChatMsg == "play":
                        if "play" not in twitchChat:
                            twitchChat["play"] = 1
                        else:
                            twitchChat["play"] += 1
                    elif clensedChatMsg == "pet":
                        if "pet" not in twitchChat:
                            twitchChat["pet"] = 1
                        else:
                            twitchChat["pet"] += 1
                    elif clensedChatMsg == "turtle":
                        if "turtle" not in twitchChat:
                            twitchChat["turtle"] = 1
                        else:
                            twitchChat["turtle"] += 1
                    elif clensedChatMsg == "golden":
                        print("HERE")
                        if "golden" not in twitchChat:
                            twitchChat["golden"] = 1
                        else:
                            twitchChat["golden"] += 1
                    elif clensedChatMsg == "puppy":
                        if "puppy" not in twitchChat:
                            twitchChat["puppy"] = 1
                        else:
                            twitchChat["puppy"] += 1
                    elif clensedChatMsg == "star":
                        if "star" not in twitchChat:
                            twitchChat["star"] = 1
                        else:
                            twitchChat["star"] += 1
                    elif clensedChatMsg == "weekly":
                        if "weekly" not in twitchChat:
                            twitchChat["weekly"] = 1
                        else:
                            twitchChat["weekly"] += 1
                    elif clensedChatMsg == "back":
                        if "back" not in twitchChat:
                            twitchChat["back"] = 1
                        else:
                            twitchChat["back"] += 1

# Checks if image is in the screen
def check_if_image_on_screen(image_path, threshold=0.8):
    # Load the image to search for
    template = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

    # Capture the screen
    screen = np.array(ImageGrab.grab(bbox=(0,0,1920,1080)))
    screen_gray = cv2.cvtColor(screen, cv2.COLOR_BGR2GRAY)

    # Perform template matching to search for the image
    result = cv2.matchTemplate(screen_gray, template, cv2.TM_CCOEFF_NORMED)

    # Get the coordinates of the matching area
    loc = np.where(result >= threshold)

    if len(loc[0]) > 0:
        return True
    else:
        return False

if __name__ == "__main__":
    x = threading.Thread(target=thread_function, args=())
    x.start()
    stopped = False
    fromPicked = False
    toDone = False
    toNumber = 0
    fromNumber = 0
    timer = 10
    while True:
        # Write timer to timer.txt
        with open("timer.txt", "w") as f:
            f.write("Timer: " + str(timer))
            if fromNumber != 0:
                f.write("\nFrom: " + str(fromNumber))
            f.close()
        if check_if_image_on_screen("Arena Mode.png"):
            needInput = True
            print("Arena Mode is on screen")
            pyautogui.keyDown('insert')
            time.sleep(0.05)
            pyautogui.keyUp('insert')
            if timer != 0:
                timer -= 1
            else:
                # Check if play or pet has more votes
                if "play" in twitchChat and "pet" in twitchChat:
                    if twitchChat["play"] >= twitchChat["pet"]:
                        pyautogui.click(750, 400)
                    else:
                        pyautogui.click(1500, 250)
                elif "play" in twitchChat:
                    pyautogui.click(750, 400)
                elif "pet" in twitchChat:
                    pyautogui.click(1500, 250)
                timer = 10
                twitchChat = {}
        elif check_if_image_on_screen("packs.png"):
            needInput = True
            print("Packs is on screen")
            pyautogui.keyDown('end')
            time.sleep(0.05)
            pyautogui.keyUp('end')
            if timer != 0:
                timer -= 1
            else:
                # checks the max votes between turtle, golden, puppy, star and weekly
                print(twitchChat)
                turtleVotes = 0
                goldenVotes = 0
                puppyVotes = 0
                starVotes = 0
                weeklyVotes = 0
                backVotes = 0
                max = 0
                winner = ""
                if "turtle" in twitchChat:
                    turtleVotes = twitchChat["turtle"]
                    if turtleVotes > max:
                        max = turtleVotes
                        winner = "turtle"
                if "golden" in twitchChat:
                    goldenVotes = twitchChat["golden"]
                    if goldenVotes > max:
                        max = goldenVotes
                        winner = "golden"
                if "puppy" in twitchChat:
                    puppyVotes = twitchChat["puppy"]
                    if puppyVotes > max:
                        max = puppyVotes
                        winner = "puppy"
                if "star" in twitchChat:
                    starVotes = twitchChat["star"]
                    if starVotes > max:
                        max = starVotes
                        winner = "star"
                if "weekly" in twitchChat:
                    weeklyVotes = twitchChat["weekly"]
                    if weeklyVotes > max:
                        max = weeklyVotes
                        winner = "weekly"
                if "back" in twitchChat:
                    backVotes = twitchChat["back"]
                    if backVotes > max:
                        max = backVotes
                        winner = "back"
                if winner == "turtle":
                    pyautogui.click(180, 550)
                elif winner == "golden":
                    pyautogui.click(572, 550)
                elif winner == "puppy":
                    pyautogui.click(964, 550)
                elif winner == "star":
                    pyautogui.click(1356, 550)
                elif winner == "weekly":
                    pyautogui.click(1750, 550)
                elif winner == "back":
                    pyautogui.click(180, 1000)
                timer = 10
                twitchChat = {}
        elif check_if_image_on_screen("Battle.png"):
            print("Battle is on screen")
            needInput = True
            if not fromPicked:
                pyautogui.keyDown('pageup')
                time.sleep(0.05)
                pyautogui.keyUp('pageup')
            else:
                pyautogui.keyDown('pagedown')
                time.sleep(0.05)
                pyautogui.keyUp('pagedown')
            if timer != 0:
                timer -= 1
            else:
                if fromPicked and toDone:
                    needInput = False
                    if fromNumber == 13 or toNumber == 13:
                        pyautogui.click (200,1000)
                        time.sleep(0.2)
                    elif fromNumber == 14 or toNumber == 14:
                        pyautogui.click (1700,1000)
                        time.sleep(0.2)
                    else:
                        if fromNumber < 6:
                            pyautogui.click(540 + (fromNumber - 1) * 145, 400)
                            time.sleep(0.2)
                        else:
                            pyautogui.click(540 + (fromNumber - 6) * 145, 700)
                            time.sleep(0.2)
                        if toNumber < 6:
                            pyautogui.click(540 + (toNumber - 1) * 145, 400)
                            time.sleep(0.2)
                        else:
                            pyautogui.click(540 + (toNumber - 6) * 145, 700)
                            time.sleep(0.2)
                    pyautogui.click(1700, 700)
                    fromPicked = False
                    timer = 10
                    toDone = False
                    toNumber = 0
                    fromNumber = 0
                elif fromPicked:
                    needInput = True
                    # Get the most picked number
                    max = 0
                    for key, value in twitchChat.items():
                        if not isinstance(key, int):
                            continue
                        if value > max:
                            max = value
                            toNumber = key
                    if not max == 0:
                        toDone = True
                    else:
                        timer = 10
                    twitchChat = {}
                else:
                    needInput = True
                    # Get the most picked number
                    max = 0
                    for key, value in twitchChat.items():
                        # if key isn't an instance of int, skip it
                        if not isinstance(key, int):
                            continue
                        if value > max:
                            max = value
                            fromNumber = key
                    if not max == 0:
                        fromPicked = True
                    if fromNumber == 13:
                        toNumber = 13
                        fromPicked = True
                        toDone = True
                    elif fromNumber == 14:
                        toNumber = 14
                        fromPicked = True
                        toDone = True
                    timer = 10
                    twitchChat = {}
        elif check_if_image_on_screen("Pause.png"):
            needInput = False
            print("Pause is on screen")
            pyautogui.keyDown('home')
            time.sleep(0.05)
            pyautogui.keyUp('home')
            print("Battling")
        elif check_if_image_on_screen("endBattle.png") or check_if_image_on_screen("endBattle2.png"):
            needInput = False
            print("endBattle is on screen")
            pyautogui.click(1700, 700)
            time.sleep(3)
            pyautogui.click(1700, 700)
        else:
            print("Nothing is on screen")
            pyautogui.keyDown('home')
            time.sleep(0.05)
            pyautogui.keyUp('home')
        
        time.sleep(1)

